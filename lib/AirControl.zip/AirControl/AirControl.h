// -------------------------------------------------
// Copyright (c) 2022 HiBit <https://www.hibit.dev>
// -------------------------------------------------

#ifndef AirControl
#define AirControl

    struct button {
        byte pressed = 0;
    };

    struct toggle {
        byte on = 0;
    };

    struct potentiometer {
        byte level = 0;
    };

    struct analog {
        short x, y;

        button button;
    };

    //Max size of this struct is 32 bytes - NRF24L01 buffer limit
    struct air_control {
        char key[10] = "hibit";

        struct {
          analog left, right;
        } analogs;

        struct {
          toggle upper, lower;
        } toggles;

        struct {
          struct {
            button upper, lower;
          } left, right;
        } buttons;

        struct {
          potentiometer left, right;
        } potentiometers;
    };

    void debug(air_control air_control);

#endif
