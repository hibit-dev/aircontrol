// -------------------------------------------------
// Copyright (c) 2022 HiBit <https://www.hibit.dev>
// -------------------------------------------------

#include "Arduino.h"

#include "AirControl.h"

void debug(air_control air_control)
{
  char buff[40];

  sprintf(buff, "Security key: %s", air_control.key);
  Serial.println(buff);

  sprintf(buff, "Size of struct: %d bytes", sizeof(air_control));
  Serial.println(buff);

  sprintf(buff, "[%d] \t %03d \t\t %03d \t [%d]", air_control.buttons.left.upper.pressed, air_control.potentiometers.left.level, air_control.potentiometers.right.level, air_control.buttons.right.upper.pressed);
  Serial.println(buff);

  sprintf(buff, "[%d] \t\t\t\t [%d]", air_control.buttons.left.lower.pressed, air_control.buttons.right.lower.pressed);
  Serial.println(buff);
  Serial.println();

  sprintf(buff, "     %03d \t\t     %03d", max(0, air_control.analogs.left.y), max(0, air_control.analogs.right.y));
  Serial.println(buff);

  sprintf(buff, " %03d [%d] %03d \t\t %03d [%d] %03d ", abs(min(0, air_control.analogs.left.x)), air_control.analogs.left.button.pressed, max(0, air_control.analogs.left.x), abs(min(0, air_control.analogs.right.x)), air_control.analogs.right.button.pressed, max(0, air_control.analogs.right.x));
  Serial.println(buff);

  sprintf(buff, "     %03d \t\t     %03d", abs(min(0, air_control.analogs.left.y)), abs(min(0, air_control.analogs.right.y)));
  Serial.println(buff);
  Serial.println();

  sprintf(buff, "\t\t  [%d]", air_control.toggles.upper.on);
  Serial.println(buff);

  sprintf(buff, "\t\t  [%d]", air_control.toggles.lower.on);
  Serial.println(buff);

  Serial.println("\n\n");

  delay(100);
}

